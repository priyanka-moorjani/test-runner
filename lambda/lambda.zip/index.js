'use strict';
const request = require('request');
const rp = require('request-promise');
const _get = require('lodash/get');
const token = '8957b46d70ee24d34467d1cab97fcb7fc386a3af';
const testRunnerUrl = 'http://05feb637.ngrok.io';
const actions = ['reopen', ''];


const STATUS_SUCCESS = 'success';
const STATUS_PENDING = 'pending';
const STATUS_FAIL = 'failure';


const statusRequest = {
    state: "pending",
    target_url: "",
    description: "pending",
    context: "mercury unit test"
};

module.exports.handler = (event, context, callback) => {

    var response = {
        isBase64Encoded: false,
        statusCode: 200,
        headers: { },
        body: '{}'
    };

    console.log(event.body);

    callback(null, response);

    var body = event.body? JSON.parse(event.body): {};

    if(!body) {
        console.log('no body');
        return;
    }

    var statusURl = _get(body, 'pull_request.statuses_url');
    var branch = _get(body, 'pull_request.head.ref');

    var headers =  {
        'Content-Type': 'application/json',
        'user-agent': 'node.js',
        'Authorization': 'token ' + token
    };

    var statusRequest = {
        state: "pending",
        target_url: "",
        description: "pending",
        context: "mercury unit test"
    };

    console.log(statusURl  + ' ' + branch);


    if (!statusURl || !branch) {
        console.log('no status url or branch');
        return;
    }

    rp.post(statusURl, { json: statusRequest, headers: headers })
    .then((body) => {
        console.log('made pending');
        console.log(body);
        var state = _get(body, 'state');

        if(state !== 'pending') return;
        console.log('status equals pending');

        return rp.post(testRunnerUrl, { json: {
            branch: 'master'
        }});

    })
    .then((body) => {

        if(body === 'Unit Test Pass\n') {
            console.log('succes');
            statusRequest.state = 'success';
            statusRequest.description = 'Unit test succeeded';

        } else if (body === 'Unit Test Fail') {
            console.log('fail');
            statusRequest.state = 'failure';
            statusRequest.description = 'Unit test failed';
        }

        console.log(statusRequest);
        if(statusRequest.state === 'pending') return;

        return rp.post(statusURl, { json: statusRequest, headers: headers });
    })
    .then((body) => {
        console.log('body ' + body);
    });


    // request.post(statusURl, { json: statusRequest, headers: headers }, (err, response, body) => {
    //
    //     if (err) {
    //         console.log('Failed to update status to pending:' + statusURl);
    //     } else {
    //
    //         console.log('made pending');
    //         console.log(body);
    //         var state = _get(body, 'state');
    //
    //         if(state !== 'pending') return;
    //         console.log('status equals pending');
    //
    //
    //         //run unit test
    //         request.post(testRunnerUrl, { json: {
    //                 branch: 'master'
    //             }
    //         }, (err, response, body) => {
    //             console.log(body);
    //
    //             if (err) {
    //                 statusRequest.state = 'error';
    //                 statusRequest.description = 'Failed to run unit test';
    //             }
    //
    //             if(body === 'Unit Test Pass\n') {
    //                 console.log('succes');
    //                 statusRequest.state = 'success';
    //                 statusRequest.description = 'Unit test succeeded';
    //
    //             } else if (body === 'Unit Test Fail') {
    //                 console.log('fail');
    //                 statusRequest.state = 'failure';
    //                 statusRequest.description = 'Unit test failed';
    //             }
    //
    //             console.log(statusRequest);
    //             if(statusRequest.state === 'pending') return;
    //
    //             request.post(statusURl, { json: statusRequest, headers: headers }, (err, resp, body) => {
    //
    //                 if(err) {
    //                     console.log('err ' + err);
    //                 }
    //
    //                 console.log('body ' + body);
    //             });
    //
    //         });
    //     }
    // });

};


